package facerecognition.javafaces;

public class FaceRecError extends Exception {

	public FaceRecError(String msg){
		super(msg);
	}
}
